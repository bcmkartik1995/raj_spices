<?php

namespace App\Http\Livewire\Website;

use Livewire\Component;

class ProductSearch extends Component
{
    public function render()
    {
        return view('livewire.website.product-search');
    }
}
